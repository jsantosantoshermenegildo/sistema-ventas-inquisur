// utils/sunat-config.js — Configuración de SUNAT
export const SUNAT_CONFIG = {
  TOKEN: "e39700ae0edb341a033943864a0e921d41b7e4abd708ba57bc8b9339dde53176",
  APIPERU_ENDPOINT: "https://apiperu.dev/api/dni-ruc"
};
