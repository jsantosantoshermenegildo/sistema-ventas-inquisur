// ========================================
// STATE - EXPORTA EL STATE MANAGER GLOBAL
// ========================================

export { appState, appState as default } from './core/StateManager.js';
